# Cook Together — Interactive Demo v0.2.0

**A working, mobile-friendly UK meal-planning and shopping-list prototype.**

> **Important:** This is a *newly reconstructed demo* from the Cook Together requirements discussed in ChatGPT on 30 October 2026. It is **not** a recovered or verified latest build from any earlier chat or private GitHub repository. No previous source code was available in the conversation.

## What works

- Browse and search 16 illustrated family-friendly recipes.
- Filter by quick, budget, vegetarian, family-favourite and saved favourites.
- Read recipe ingredients and cooking steps.
- Plan a dinner for each day of the week and change portions (1–12).
- See an *illustrative* planned-dinner budget in pounds sterling (£).
- Generate a combined shopping list with quantities adjusted for portions.
- Tick off purchased items and add extra shopping items manually.
- Mark ingredients in your pantry so they are hidden from your shopping list.
- Add demo household names, copy your meal plan or shopping list.
- Export/import all your browser-stored demo data as JSON.
- Install as a basic PWA from a supported browser when hosted over HTTPS; basic offline support.
- Link to Tesco, Sainsbury's, Asda or Morrisons websites.

## What **does not** work yet

- **No real multi-user syncing or account system:** household names are only local demo data.
- **No live grocery prices, available-stock data or automatic checkout.** The selected supermarket opens separately. You must manually add products on their website.
- **No retailer commission or order tracking.** There is no commercial integration.
- **No actual payments, delivery booking, nutrition calculation or allergy guarantee.**
- Prices are intentionally illustrative and may not resemble today's shelf prices.

This is a *validation prototype*, not a production-ready commercial shopping service. Do not rely on allergy flags without checking actual product packaging.

## New in v0.2.0

The **weekly Meal planner → Choose a meal / Change** buttons now open a mobile-friendly meal chooser. It uses stacked, fully visible recipe cards rather than a sideways-scrolling carousel; you can search recipes and ingredients, filter by quick, budget, vegetarian or favourites, inspect ingredients, set portions and add a meal directly to the chosen day. The main Recipes page remains available too.

## Try it on your computer

Option A: Open `index.html` in a modern browser. Most features work directly. For PWA installation, use the local server option below.

Option B: Serve it locally:

```bash
python3 -m http.server 8000
```

Then visit http://localhost:8000/ in your browser.

No npm packages, API keys, build steps or backend required.

## Upload to GitHub and publish it with GitHub Pages

**If you're starting a new repository:**

1. Sign in to GitHub and create a new repository, e.g. `cook-together`.
2. Download and unzip this project. **Upload the contents** of the folder into the root of the repository. The file `index.html` must be at the repository root.
3. On GitHub, use **Add file → Upload files**, drop in the unzipped files and `assets` folder, then commit the changes to the `main` branch. If GitHub's web uploader does not preserve the folder structure, upload the `assets` folder using GitHub Desktop or git instead.
4. Open **Settings → Pages → Build and deployment**.
5. Set **Source = Deploy from a branch**, **Branch = main**, and **Folder = / (root)**, then save.
6. Once GitHub Pages finishes deploying, open the URL shown there, usually `https://YOUR-USERNAME.github.io/cook-together/`.

**If you're updating an existing repository:** Make a backup or branch first. Compare the contents before replacing files; this demo might not match your earlier implementation.

### Via terminal (alternative)

From inside this project's directory:

```bash
git init
git add .
git commit -m "Add Cook Together interactive demo v0.2.0"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/cook-together.git
git push -u origin main
```

That push assumes you've created an empty GitHub repository and have Git credentials set up.

## How data works

This demo uses browser `localStorage` under `cook-together-demo-v1`. Data remains in that browser only. Incognito sessions and clearing browser storage may delete it. Use **Settings → Download backup** if you want to preserve a plan. There is no server-side backup.

## Files

```text
index.html             App shell
styles.css             Responsive layout and styling
recipes.js             Illustrative recipe catalogue
app.js                 Client-side app logic
manifest.webmanifest   Installable app metadata
service-worker.js      Offline app-shell cache
assets/                App icons
.nojekyll              GitHub Pages compatibility
```

## Follow-up development work

1. Test with 20–30 real households and observe 4-week repeat use.
2. Build accounts, private household permissions and server-side data syncing.
3. Integrate with a retailer **through authorised APIs/partnerships** to support basket creation and (where permitted) affiliate attribution.
4. Validate ingredient matching, substitutions, pack sizes, stock availability, allergens and delivery fees.
5. Add GDPR-compliant consent, account deletion, accessibility testing, monitoring and error handling.
6. Replace illustrative recipe costs with clearly sourced and regularly updated price estimates.

Created: 30 October 2026.
