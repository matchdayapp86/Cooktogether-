# Cook Together — changes

## v0.2.0 — 30 October 2026

### Meal selection redesign
- Meal planner's **Choose a meal** and **Change** buttons now open a day-specific picker.
- Mobile-first vertical cards show complete recipe names; no horizontal recipe carousel.
- Large **Choose meal** buttons put a recipe straight into the selected day.
- Search by recipe name, description, tags, or ingredient; quick, budget, veggie, and saved filters.
- Choose portions without leaving the picker; indicative recipe costs adjust with selected portion count.
- Expand ingredient summaries with illustrative allergen flags.
- Save/unsave favourites in the picker.
- Day selection, portions and favourites are stored locally in the same v0.1.0 browser data so existing plans remain intact.
- Keyboard Escape closes picker; clicking outside also closes it. Dialog keeps keyboard focus inside while open.
- Service worker cache bumped to v0.2.0.

### Important caveat
This release updates the reconstructed Cook Together v0.1.0 demo from the prior message in this conversation. It is **not a direct edit of any different app currently hosted at matchdayapp86.github.io**. Back up your existing GitHub source before replacing files. To apply this redesign to another current build, provide its GitHub repository URL or source ZIP.
