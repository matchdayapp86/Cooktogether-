// Demonstration recipe data. Costs are rough illustrations, not live supermarket prices.
window.COOK_RECIPES = [
  {
    id:'tomato-pasta', title:'Creamy tomato pasta', emoji:'🍝', theme:'tomato', time:25, servings:4, cost:6.80,
    description:'A comforting midweek pasta with a silky tomato sauce and plenty of flavour.',
    tags:['Quick','Vegetarian','Budget'], allergens:['Wheat','Milk'],
    ingredients:[['pasta','Dried pasta',400,'g','Cupboard'],['passata','Passata',500,'ml','Cupboard'],['cream-cheese','Cream cheese',150,'g','Chilled'],['onion','Onion',1,'whole','Fresh produce'],['garlic','Garlic cloves',2,'cloves','Fresh produce'],['spinach','Baby spinach',100,'g','Fresh produce']],
    steps:['Cook pasta in boiling water according to its packet instructions.','Finely chop the onion and garlic and soften in a little oil.','Add passata, simmer for 8 minutes and stir in cream cheese.','Fold in spinach until wilted, then toss with drained pasta.']
  },
  {
    id:'chicken-fajitas', title:'Chicken fajita wraps', emoji:'🌮', theme:'sunshine', time:30, servings:4, cost:10.40,
    description:'Colourful peppers, gently spiced chicken and warm tortillas to share.',
    tags:['Family favourite','High protein','Quick'], allergens:['Wheat'],
    ingredients:[['chicken','Chicken breast',600,'g','Meat & fish'],['peppers','Mixed peppers',3,'whole','Fresh produce'],['onion','Onion',1,'whole','Fresh produce'],['tortillas','Flour tortillas',8,'whole','Bakery'],['fajita-spice','Fajita seasoning',1,'pack','Cupboard'],['lime','Lime',1,'whole','Fresh produce']],
    steps:['Slice chicken, peppers and onion into even strips.','Coat chicken in seasoning and fry until fully cooked through.','Add peppers and onion; cook until tender.','Warm tortillas and serve with lime wedges.']
  },
  {
    id:'chickpea-curry', title:'Chickpea coconut curry', emoji:'🍛', theme:'golden', time:30, servings:4, cost:7.20,
    description:'A warming veggie curry with creamy coconut milk and fluffy rice.',
    tags:['Vegetarian','Vegan','Budget'], allergens:[],
    ingredients:[['chickpeas','Chickpeas',2,'tins','Cupboard'],['coconut-milk','Coconut milk',1,'tin','Cupboard'],['chopped-tomatoes','Chopped tomatoes',1,'tin','Cupboard'],['rice','Basmati rice',300,'g','Cupboard'],['onion','Onion',1,'whole','Fresh produce'],['curry-powder','Curry powder',2,'tbsp','Cupboard'],['spinach','Baby spinach',120,'g','Fresh produce']],
    steps:['Cook rice according to the packet instructions.','Softly fry diced onion with curry powder.','Add drained chickpeas, coconut milk and tomatoes; simmer for 15 minutes.','Stir through spinach and serve over rice.']
  },
  {
    id:'beef-chilli', title:'Easy beef chilli', emoji:'🥘', theme:'ember', time:40, servings:4, cost:11.60,
    description:'A big pan of flavour-packed chilli for cosy evenings and leftovers.',
    tags:['Family favourite','Batch cook','High protein'], allergens:[],
    ingredients:[['beef-mince','Beef mince',500,'g','Meat & fish'],['kidney-beans','Kidney beans',1,'tin','Cupboard'],['chopped-tomatoes','Chopped tomatoes',2,'tins','Cupboard'],['onion','Onion',1,'whole','Fresh produce'],['rice','Basmati rice',300,'g','Cupboard'],['chilli-powder','Chilli powder',1,'tsp','Cupboard'],['peppers','Mixed peppers',1,'whole','Fresh produce']],
    steps:['Brown the mince thoroughly in a large pan.','Add chopped onion and pepper and soften.','Stir in tomatoes, drained beans and chilli powder; simmer for 20 minutes.','Cook the rice separately and serve.']
  },
  {
    id:'salmon-traybake', title:'Lemon salmon traybake', emoji:'🐟', theme:'ocean', time:35, servings:4, cost:16.50,
    description:'Salmon, roast potatoes and broccoli on one tray, with bright lemon.',
    tags:['One tray','High protein'], allergens:['Fish'],
    ingredients:[['salmon','Salmon fillets',4,'whole','Meat & fish'],['potatoes','Potatoes',800,'g','Fresh produce'],['broccoli','Broccoli',2,'heads','Fresh produce'],['lemon','Lemon',1,'whole','Fresh produce'],['olive-oil','Olive oil',2,'tbsp','Cupboard']],
    steps:['Preheat oven to 200°C fan. Cut potatoes into small chunks.','Toss potatoes in oil and roast for 15 minutes.','Add salmon and broccoli, season and squeeze over lemon.','Roast until salmon is cooked through and potatoes are tender.']
  },
  {
    id:'veggie-stirfry', title:'Rainbow noodle stir-fry', emoji:'🍜', theme:'mint', time:20, servings:4, cost:8.40,
    description:'Crisp vegetables and noodles in a quick, sticky ginger-soy sauce.',
    tags:['Quick','Vegetarian','Budget'], allergens:['Wheat','Soy'],
    ingredients:[['noodles','Egg noodles',300,'g','Cupboard'],['stirfry-veg','Stir-fry vegetables',500,'g','Fresh produce'],['soy-sauce','Soy sauce',4,'tbsp','Cupboard'],['ginger','Fresh ginger',30,'g','Fresh produce'],['garlic','Garlic cloves',2,'cloves','Fresh produce'],['honey','Honey',2,'tbsp','Cupboard']],
    steps:['Cook noodles as directed and drain.','Stir-fry the vegetables until just tender.','Add minced garlic and ginger, then soy sauce and honey.','Toss noodles through the pan and serve hot.']
  },
  {
    id:'jacket-potatoes', title:'Jacket potatoes & beans', emoji:'🥔', theme:'earth', time:60, servings:4, cost:5.50,
    description:'A great-value classic with baked potatoes, beans and melted cheese.',
    tags:['Vegetarian','Budget','Family favourite'], allergens:['Milk'],
    ingredients:[['potatoes','Potatoes',4,'large','Fresh produce'],['baked-beans','Baked beans',2,'tins','Cupboard'],['cheddar','Cheddar',160,'g','Chilled'],['butter','Butter',40,'g','Chilled']],
    steps:['Heat oven to 200°C fan and prick potatoes with a fork.','Bake potatoes until soft inside; usually 50–60 minutes depending on size.','Warm beans thoroughly in a saucepan.','Split potatoes and top with butter, beans and grated cheese.']
  },
  {
    id:'sausage-gnocchi', title:'Sausage & tomato gnocchi', emoji:'🍲', theme:'coral', time:25, servings:4, cost:10.90,
    description:'A hearty one-pan dinner with golden sausages and pillowy gnocchi.',
    tags:['One pan','Family favourite','Quick'], allergens:['Wheat','Milk'],
    ingredients:[['sausages','Pork sausages',8,'whole','Meat & fish'],['gnocchi','Potato gnocchi',500,'g','Chilled'],['passata','Passata',500,'ml','Cupboard'],['spinach','Baby spinach',100,'g','Fresh produce'],['onion','Onion',1,'whole','Fresh produce'],['cheddar','Cheddar',80,'g','Chilled']],
    steps:['Slice sausages and cook until browned and cooked through.','Add chopped onion and soften.','Stir in passata and gnocchi; simmer until gnocchi is tender.','Add spinach and finish with grated cheese.']
  },
  {
    id:'tuna-pasta', title:'Tuna pasta bake', emoji:'🧀', theme:'lavender', time:40, servings:4, cost:8.70,
    description:'A bubbling cheesy pasta bake made from simple cupboard ingredients.',
    tags:['Family favourite','Batch cook','Budget'], allergens:['Fish','Wheat','Milk'],
    ingredients:[['pasta','Dried pasta',400,'g','Cupboard'],['tuna','Tinned tuna',2,'tins','Cupboard'],['sweetcorn','Sweetcorn',1,'tin','Cupboard'],['passata','Passata',500,'ml','Cupboard'],['cheddar','Cheddar',180,'g','Chilled']],
    steps:['Heat oven to 190°C fan and boil pasta until just underdone.','Drain pasta and mix with tuna, sweetcorn and passata.','Tip into a baking dish and top with grated cheese.','Bake for 15–20 minutes until hot and golden.']
  },
  {
    id:'pesto-chicken', title:'Chicken pesto pasta', emoji:'🌿', theme:'sage', time:25, servings:4, cost:12.20,
    description:'A quick bowl of pesto-coated pasta with juicy chicken and tomatoes.',
    tags:['Quick','Family favourite','High protein'], allergens:['Wheat','Milk','Nuts'],
    ingredients:[['chicken','Chicken breast',500,'g','Meat & fish'],['pasta','Dried pasta',350,'g','Cupboard'],['pesto','Basil pesto',150,'g','Cupboard'],['cherry-tomatoes','Cherry tomatoes',250,'g','Fresh produce'],['spinach','Baby spinach',100,'g','Fresh produce']],
    steps:['Cook pasta as directed.','Dice chicken and fry until cooked all the way through.','Add halved tomatoes and spinach; cook briefly.','Combine with drained pasta and pesto.']
  },
  {
    id:'lentil-bolognese', title:'Lentil bolognese', emoji:'🍅', theme:'tomato', time:35, servings:4, cost:7.80,
    description:'An easy, filling plant-based bolognese that works beautifully with spaghetti.',
    tags:['Vegetarian','Vegan','Budget','Batch cook'], allergens:['Wheat'],
    ingredients:[['lentils','Tinned lentils',2,'tins','Cupboard'],['spaghetti','Spaghetti',400,'g','Cupboard'],['chopped-tomatoes','Chopped tomatoes',2,'tins','Cupboard'],['carrots','Carrots',2,'whole','Fresh produce'],['onion','Onion',1,'whole','Fresh produce'],['garlic','Garlic cloves',2,'cloves','Fresh produce']],
    steps:['Finely dice onion and carrots; cook until softened.','Add garlic, tomatoes and drained lentils; simmer 20 minutes.','Cook spaghetti in a separate pan.','Serve sauce over spaghetti.']
  },
  {
    id:'mushroom-risotto', title:'Creamy mushroom risotto', emoji:'🍄', theme:'earth', time:40, servings:4, cost:9.60,
    description:'Comforting rice with earthy mushrooms and a little parmesan.',
    tags:['Vegetarian','Comfort food'], allergens:['Milk'],
    ingredients:[['risotto-rice','Risotto rice',350,'g','Cupboard'],['mushrooms','Mushrooms',400,'g','Fresh produce'],['veg-stock','Vegetable stock',1,'litre','Cupboard'],['onion','Onion',1,'whole','Fresh produce'],['parmesan','Parmesan',70,'g','Chilled'],['butter','Butter',30,'g','Chilled']],
    steps:['Soften finely diced onion in butter.','Add sliced mushrooms and cook until golden.','Add rice and gradually stir in hot stock until creamy and rice is cooked.','Stir through parmesan and season.']
  },
  {
    id:'shepherds-pie', title:'Homestyle shepherd’s pie', emoji:'🥧', theme:'golden', time:55, servings:4, cost:12.80,
    description:'Lamb mince and vegetables under a golden mashed potato topping.',
    tags:['Family favourite','Comfort food','Batch cook'], allergens:['Milk'],
    ingredients:[['lamb-mince','Lamb mince',500,'g','Meat & fish'],['potatoes','Potatoes',900,'g','Fresh produce'],['carrots','Carrots',2,'whole','Fresh produce'],['peas','Frozen peas',200,'g','Frozen'],['onion','Onion',1,'whole','Fresh produce'],['butter','Butter',40,'g','Chilled'],['veg-stock','Vegetable stock',250,'ml','Cupboard']],
    steps:['Heat oven to 200°C fan. Boil potatoes until soft and mash with butter.','Brown mince thoroughly and add diced onion and carrot.','Add peas and stock; simmer until thickened.','Spread mash on top and bake until golden and piping hot.']
  },
  {
    id:'teriyaki-noodles', title:'Teriyaki veggie noodles', emoji:'🥢', theme:'ocean', time:20, servings:4, cost:8.10,
    description:'Sweet-savory noodles piled high with crunchy vegetables.',
    tags:['Quick','Vegetarian','Budget'], allergens:['Wheat','Soy','Sesame'],
    ingredients:[['noodles','Egg noodles',300,'g','Cupboard'],['stirfry-veg','Stir-fry vegetables',500,'g','Fresh produce'],['teriyaki','Teriyaki sauce',150,'ml','Cupboard'],['sesame','Sesame seeds',2,'tbsp','Cupboard'],['spring-onions','Spring onions',1,'bunch','Fresh produce']],
    steps:['Cook noodles to packet instructions.','Stir-fry vegetables until softened but still crisp.','Pour in teriyaki sauce, add noodles and toss to heat through.','Top with sliced spring onions and sesame seeds.']
  },
  {
    id:'tortilla-pizzas', title:'Build-your-own tortilla pizzas', emoji:'🍕', theme:'coral', time:20, servings:4, cost:8.30,
    description:'Fast, fun individual pizzas that everyone can top their own way.',
    tags:['Quick','Vegetarian','Family favourite'], allergens:['Wheat','Milk'],
    ingredients:[['tortillas','Flour tortillas',8,'whole','Bakery'],['passata','Passata',250,'ml','Cupboard'],['mozzarella','Mozzarella',250,'g','Chilled'],['peppers','Mixed peppers',2,'whole','Fresh produce'],['sweetcorn','Sweetcorn',1,'tin','Cupboard']],
    steps:['Preheat oven to 200°C fan.','Put tortillas on baking trays and spread with passata.','Add mozzarella, sliced peppers and sweetcorn.','Bake until edges are crisp and cheese is bubbling.']
  },
  {
    id:'halloumi-couscous', title:'Roasted veg & halloumi couscous', emoji:'🥗', theme:'mint', time:30, servings:4, cost:11.40,
    description:'Fluffy couscous with roasted vegetables and golden halloumi.',
    tags:['Vegetarian','One tray'], allergens:['Wheat','Milk'],
    ingredients:[['halloumi','Halloumi',400,'g','Chilled'],['couscous','Couscous',300,'g','Cupboard'],['courgette','Courgettes',2,'whole','Fresh produce'],['peppers','Mixed peppers',2,'whole','Fresh produce'],['lemon','Lemon',1,'whole','Fresh produce'],['olive-oil','Olive oil',2,'tbsp','Cupboard']],
    steps:['Heat oven to 200°C fan and chop vegetables.','Toss vegetables in oil and roast for 20 minutes.','Prepare couscous according to packet instructions.','Pan-fry sliced halloumi until golden, then serve everything with lemon.']
  }
];
window.COOK_DAYS = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
