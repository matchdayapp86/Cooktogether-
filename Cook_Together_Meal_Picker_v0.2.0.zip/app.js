/* Cook Together — browser-only demonstration. No backend, purchases or real household sync. */
(() => {
  'use strict';
  const RECIPES = window.COOK_RECIPES;
  const DAYS = window.COOK_DAYS;
  const KEY = 'cook-together-demo-v1';
  const iconPaths = {
    home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
    book:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
    calendar:'<rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/>',
    cart:'<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.6 13.5a2 2 0 0 0 2 1.5h9.8a2 2 0 0 0 2-1.5L23 6H6"/>',
    pantry:'<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M3 11h18M9 11v10M15 11v10M7 7h2M15 7h2"/>',
    people:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
    settings:'<path d="M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/><path d="m19.4 15 .1.1 1.5 1.2-1.6 2.8-1.8-.7a8.3 8.3 0 0 1-2 1.2l-.3 1.9h-3.3l-.3-1.9a8.3 8.3 0 0 1-2-1.2l-1.8.7-1.6-2.8 1.5-1.2a8 8 0 0 1 0-2.3l-1.5-1.2 1.6-2.8 1.8.7a8 8 0 0 1 2-1.2l.3-1.9h3.3l.3 1.9a8 8 0 0 1 2 1.2l1.8-.7 1.6 2.8-1.5 1.2a8 8 0 0 1 0 2.3z" transform="translate(-1 -2) scale(1.05)"/>',
    plus:'<path d="M12 5v14M5 12h14"/>',
    arrow:'<path d="M5 12h14M12 5l7 7-7 7"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8z"/>',
    check:'<path d="m5 12 4 4L19 6"/>',
    cash:'<rect x="2" y="5" width="20" height="14" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 9h.01M18 15h.01"/>',
    download:'<path d="M12 3v12m-5-5 5 5 5-5M4 17v4h16v-4"/>',
    printer:'<path d="M6 9V3h12v6M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 15h12v7H6z"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="m16 16 5 5"/>',
    leaf:'<path d="M20 4c-10 0-16 5-16 11a5 5 0 0 0 5 5c7 0 11-8 11-16zM5 19c3-5 7-8 12-11"/>',
    edit:'<path d="m16 4 4 4M3 21l4.5-1 12-12a2.8 2.8 0 0 0-4-4l-12 12L3 21z"/>',
    trash:'<path d="M3 6h18M8 6V4h8v2M5 6l1 15h12l1-15M10 10v7M14 10v7"/>',
    sparkle:'<path d="m12 2 2.2 7.8L22 12l-7.8 2.2L12 22l-2.2-7.8L2 12l7.8-2.2z"/>',
    external:'<path d="M13 5h6v6M19 5l-9 9"/><path d="M19 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2h5"/>'
  };
  const ic=(n)=>`<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round" stroke-linecap="round" aria-hidden="true">${iconPaths[n]||iconPaths.sparkle}</svg>`;
  const navItems=[['home','Your kitchen','home'],['recipes','Find recipes','book'],['planner','Meal planner','calendar'],['shopping','Shopping list','cart'],['pantry','My pantry','pantry'],['household','Household','people'],['settings','Settings','settings']];
  const mobileItems=['home','recipes','planner','shopping','pantry','household'];
  const esc=(v)=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const pounds=n=>'£'+Number(n||0).toFixed(2);
  const count=n=>Number(n).toLocaleString('en-GB',{maximumFractionDigits:1});
  const recipeById=id=>RECIPES.find(r=>r.id===id);
  const defaultState=()=>({version:1,budget:85,servings:4,plan:{Monday:{id:'tomato-pasta',servings:4},Wednesday:{id:'chicken-fajitas',servings:4},Friday:{id:'chickpea-curry',servings:4},Sunday:{id:'salmon-traybake',servings:4}},favorites:['chickpea-curry','chicken-fajitas'],pantry:['olive-oil','rice','garlic'],checked:{},manual:[],members:['You'],name:'Our kitchen',retailer:'tesco'});
  const load=()=>{try{const s=JSON.parse(localStorage.getItem(KEY));if(!s||s.version!==1)return defaultState();return {...defaultState(),...s,plan:s.plan&&typeof s.plan==='object'?s.plan:{},favorites:Array.isArray(s.favorites)?s.favorites:[],pantry:Array.isArray(s.pantry)?s.pantry:[],manual:Array.isArray(s.manual)?s.manual:[],members:Array.isArray(s.members)?s.members:[],checked:s.checked&&typeof s.checked==='object'?s.checked:{}}}catch{return defaultState()}};
  let state=load(),page='home',filter='All',search='',pendingDay=null,modalRecipe=null,toastTimer=null;
  let pickerDay=null,pickerFilter='All',pickerQuery='',pickerServings=4,pickerPreviousFocus=null;
  const save=()=>{try{localStorage.setItem(KEY,JSON.stringify(state))}catch{toast('Browser storage is unavailable. Changes may not be saved.')}};
  const plannedEntries=()=>DAYS.map(d=>({day:d,...(state.plan[d]||{})})).filter(p=>recipeById(p.id));
  const plannedCost=()=>plannedEntries().reduce((a,p)=>a+recipeById(p.id).cost*p.servings/recipeById(p.id).servings,0);
  function shopIngredients(){
    const ingredients=new Map();
    plannedEntries().forEach(p=>{let r=recipeById(p.id);r.ingredients.forEach(([id,name,qty,unit,aisle])=>{const scale=p.servings/r.servings;const key=id+'::'+unit;if(!ingredients.has(key))ingredients.set(key,{key,id,name,qty:0,unit,aisle});ingredients.get(key).qty+=qty*scale})});
    return [...ingredients.values()].sort((a,b)=>a.aisle.localeCompare(b.aisle)||a.name.localeCompare(b.name));
  }
  function ingredientAmount(qty,unit){const v=count(Number(qty.toFixed(2)));return unit==='whole'||unit==='cloves'||unit==='heads'||unit==='large'||unit==='tins'||unit==='tin'||unit==='pack'||unit==='bunch'?`${v} ${unit==='whole'?'':unit}`.trim():`${v}${['g','ml'].includes(unit)?unit:' '+unit}`;}
  const stocked=()=>shopIngredients().filter(i=>state.pantry.includes(i.id));
  const required=()=>shopIngredients().filter(i=>!state.pantry.includes(i.id));
  const shoppingTotal=()=>required().length+state.manual.length;
  const shoppingDone=()=>required().filter(i=>state.checked[i.key]).length+state.manual.filter(i=>i.checked).length;
  function pageHead(eye,title,sub,action=''){return `<div class="page-head"><div><div class="eyebrow">${esc(eye)}</div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div>${action}</div>`}
  const btn=(text,action,extra='',cls='btn')=>`<button type="button" class="${cls}" data-action="${action}" ${extra}>${text}</button>`;
  function recipeCard(r){const fav=state.favorites.includes(r.id);return `<article class="recipe-card"><div class="recipe-picture theme-${r.theme}"><span class="food" role="img" aria-label="${esc(r.title)}">${r.emoji}</span><button type="button" class="icon-btn heart ${fav?'is-favourite':''}" data-action="favorite" data-id="${r.id}" aria-label="${fav?'Remove from':'Add to'} favourites">${ic('heart')}</button></div><div class="recipe-content"><button class="recipe-open" data-action="recipe" data-id="${r.id}"><h3>${esc(r.title)}</h3><p>${esc(r.description)}</p></button><div class="recipe-tags">${r.tags.slice(0,2).map(t=>`<span class="pill ${t==='Budget'?'peach':''}">${esc(t)}</span>`).join('')}</div><div class="recipe-meta"><span>⏱ ${r.time} min · ${r.servings} portions</span><strong>~${pounds(r.cost)}</strong></div></div></article>`}
  function renderNav(){
    document.getElementById('desktop-nav').innerHTML=navItems.map(([id,label,icon])=>`<button type="button" class="nav-button ${page===id?'active':''}" data-page="${id}" ${page===id?'aria-current="page"':''}>${ic(icon)}${esc(label)}</button>`).join('');
    document.getElementById('mobile-nav').innerHTML=navItems.filter(i=>mobileItems.includes(i[0])).map(([id,label,icon])=>`<button type="button" class="${page===id?'active':''}" data-page="${id}" ${page===id?'aria-current="page"':''}>${ic(icon)}<span>${esc(label==='Your kitchen'?'Home':label==='Find recipes'?'Recipes':label==='Meal planner'?'Plan':label==='Shopping list'?'Shop':label==='My pantry'?'Pantry':label)}</span></button>`).join('');
    document.getElementById('breadcrumb').textContent=(navItems.find(n=>n[0]===page)||navItems[0])[1];
  }
  function renderHome(){
    const p=plannedEntries();const total=plannedCost();const budget=Math.max(1,Number(state.budget)||85);
    const featured=['tomato-pasta','chicken-fajitas','chickpea-curry'].map(recipeById);
    return `<section class="hero"><div class="hero-copy"><div class="eyebrow">WELCOME TO YOUR KITCHEN ✦</div><h1>Good meals.<br>Better together.</h1><p>Plan delicious dinners, keep the budget in check and turn your menu into one easy shopping list.</p>${btn('Plan this week '+ic('arrow'),'go-planner','','btn btn-orange')}</div><div class="hero-art" aria-hidden="true">🥘</div></section>
    <section class="grid stats-grid" aria-label="Kitchen summary">
      <div class="stat-card"><div><small>Meals planned</small><strong>${p.length} <span style="font-size:13px;color:#8a9b90">/ 7</span></strong><p>Evenings sorted</p></div><div class="stat-icon">${ic('calendar')}</div></div>
      <div class="stat-card"><div><small>Shopping items</small><strong>${shoppingTotal()}</strong><p>${shoppingDone()} ticked off</p></div><div class="stat-icon">${ic('cart')}</div></div>
      <div class="stat-card"><div><small>Estimated dinners</small><strong>${pounds(total)}</strong><p>Of ${pounds(budget)} budget</p></div><div class="stat-icon">${ic('cash')}</div></div>
    </section>
    <section class="grid two-col" style="margin-bottom:30px"><div class="surface"><div class="section-heading"><h2>This week's menu</h2>${btn('View full week →','go-planner','','btn btn-plain btn-sm')}</div><div class="compact-days">${(p.length?p.slice(0,4):[{day:'Monday',id:null}]).map(x=>{const r=recipeById(x.id);return `<div class="compact-day"><span class="compact-day-label">${esc(x.day.slice(0,3))}</span><span class="compact-day-img">${r?r.emoji:'🍽️'}</span><span style="flex:1;min-width:0"><strong>${r?esc(r.title):'Nothing planned yet'}</strong><small style="display:block">${r?r.time+' min · '+x.servings+' portions':'Pick your first meal'}</small></span><button data-action="${r?'recipe':'go-recipes'}" ${r?'data-id="'+r.id+'"':''}>${r?'View':'Add'} →</button></div>`}).join('')}</div>${p.length>4?`<p class="subline" style="margin:13px 0 0">+ ${p.length-4} more meals planned</p>`:''}</div>
      <div class="surface"><div class="section-heading"><h2>Your food budget</h2></div><div class="eyebrow" style="margin-bottom:5px">ESTIMATED PLANNED DINNERS</div><div class="budget-big">${pounds(total)}</div><div class="budget-sub">out of ${pounds(budget)} weekly target</div><div class="progress-track"><div class="progress-fill" style="width:${Math.min(100,total/budget*100)}%;background:${total>budget?'#eaa17f':''}"></div></div><div class="budget-detail"><span>${Math.round(total/budget*100)}% of target</span><strong>${total>budget?pounds(total-budget)+' over':pounds(budget-total)+' remaining'}</strong></div><div class="divider"></div><div class="help-callout"><strong>🌱 Good to know</strong><br>Budget figures cover only planned recipes and are rough examples—not live supermarket prices or a full weekly food shop.</div></div>
    </section>
    <section><div class="section-heading"><h2>What's cooking?</h2>${btn('Browse all recipes →','go-recipes','','btn btn-plain btn-sm')}</div><div class="recipes-grid">${featured.map(recipeCard).join('')}</div></section>`;
  }
  function recipeResults(){let list=RECIPES.filter(r=>(filter==='All'||(filter==='Favourites'?state.favorites.includes(r.id):r.tags.includes(filter)))&&`${r.title} ${r.description} ${r.tags.join(' ')}`.toLowerCase().includes(search.toLowerCase()));return list.length?list.map(recipeCard).join(''):`<div class="empty-state"><div class="big">🍽️</div><h3>No recipes found</h3><p>Try another search or filter to see more ideas.</p>${btn('Show all recipes','clear-filter')}</div>`}
  function renderRecipes(){return `${pageHead('THE GOOD STUFF','Find something delicious','Browse everyday dinners to plan together.',btn(ic('calendar')+' View your plan','go-planner','','btn'))}<div class="filters-row"><label class="search-box">${ic('search')}<input id="recipe-search" aria-label="Search recipes" placeholder="Search meals or ingredients" value="${esc(search)}"></label><div class="filter-pills">${['All','Quick','Budget','Vegetarian','Family favourite','Favourites'].map(t=>`<button class="filter-btn ${filter===t?'active':''}" data-action="filter" data-filter="${esc(t)}">${esc(t)}</button>`).join('')}</div></div><div id="recipe-results" class="recipes-grid">${recipeResults()}</div><div class="notice" style="margin-top:24px">Recipe prices and allergen summaries are illustrative. Always check the packaging and suitability of the actual food products you purchase.</div>`}
  function renderPlanner(){const planned=plannedEntries(),total=plannedCost();return `${pageHead('YOUR WEEK, SORTED','Meal planner','A simple dinner plan your household can enjoy.',btn(ic('plus')+' Add a recipe','go-recipes','','btn btn-primary'))}<div class="week-top"><div class="week-number"><small>MEALS PLANNED</small><strong>${planned.length} of 7 days</strong></div><div class="week-number"><small>ESTIMATED DINNER COST</small><strong>${pounds(total)}</strong></div><div class="week-number"><small>WEEKLY DINNER TARGET</small><strong>${pounds(state.budget)}</strong></div><div style="align-self:center">${btn(ic('cart')+' Shopping list','go-shopping','','btn btn-primary')}</div></div><div class="days-grid">${DAYS.map(day=>{const p=state.plan[day];const r=p&&recipeById(p.id);return `<article class="day-card"><div class="day-title"><strong>${day}</strong><span>DINNER</span></div>${r?`<div class="planned-meal"><div class="mini-art theme-${r.theme}">${r.emoji}</div><div><strong>${esc(r.title)}</strong><small>⏱ ${r.time} min · approx ${pounds(r.cost*p.servings/r.servings)}</small></div></div><div class="flex-between" style="margin-top:12px"><div class="servings-control"><span>Portions</span><button data-action="portion-minus" data-day="${day}" aria-label="Reduce ${day} portions" ${p.servings<=1?'disabled':''}>−</button><strong>${p.servings}</strong><button data-action="portion-plus" data-day="${day}" aria-label="Increase ${day} portions" ${p.servings>=12?'disabled':''}>+</button></div><div class="day-actions"><button class="btn btn-sm" data-action="change-day" data-day="${day}">${ic('edit')} Change</button><button class="icon-btn" data-action="remove-day" data-day="${day}" aria-label="Remove ${day} meal">${ic('trash')}</button></div></div>`:`<div class="meal-empty"><div class="plus-big">+</div><p>Your dinner slot is free</p>${btn('Choose a meal','fill-day',`data-day="${day}"`,'btn btn-sm')}</div>`}</article>`}).join('')}</div><p class="footer-note" style="margin-top:17px">Tip: Adjust portions before generating your shopping list. Changing meals updates ingredient quantities automatically.</p>`}
  function renderShopping(){const items=required(),complete=shoppingDone(),total=shoppingTotal(),groups=[...new Set(items.map(i=>i.aisle))].sort(),finished=total&&complete===total;
    return `${pageHead('ALL IN ONE PLACE','Shopping list','Everything needed for your planned dinners, combined automatically.',btn(ic('printer')+' Print list','print','','btn'))}<div class="shopping-top"><div class="shop-metric"><strong>${total}</strong><small>Items to get</small></div><div class="shop-metric"><strong>${complete}</strong><small>Ticked off</small></div><div class="shop-metric"><strong>${stocked().length}</strong><small>Already in pantry</small></div></div><div class="shopping-grid"><div><div class="shopping-side-actions">${btn(ic('download')+' Copy shopping list','copy-shopping','','btn btn-sm')}${btn('Clear ticks','clear-checks','','btn btn-sm')}${btn('Edit meal plan','go-planner','','btn btn-sm')}</div>${total?`<div class="progress-track" style="margin-bottom:18px"><div class="progress-fill" style="width:${(complete/total*100).toFixed(1)}%"></div></div>`:''}${finished?'<div class="app-status" style="margin-bottom:14px">✓ Everything on your list has been ticked off. Happy cooking!</div>':''}${groups.map(group=>{const sub=items.filter(i=>i.aisle===group);return `<section class="shopping-group"><h3>${esc(group)} <span>${sub.length} items</span></h3>${sub.map(i=>{const checked=!!state.checked[i.key];return `<div class="shopping-item ${checked?'is-checked':''}"><input class="check-round" id="shop-${esc(i.key)}" type="checkbox" data-action="tick-ingredient" data-key="${esc(i.key)}" ${checked?'checked':''}><label for="shop-${esc(i.key)}">${esc(i.name)}</label><span class="item-qty">${ingredientAmount(i.qty,i.unit)}</span></div>`}).join('')}</section>`}).join('')}
      ${state.manual.length?`<section class="shopping-group"><h3>Added by you <span>${state.manual.length} items</span></h3>${state.manual.map(m=>`<div class="shopping-item ${m.checked?'is-checked':''}"><input class="check-round" type="checkbox" data-action="tick-manual" data-id="${esc(m.id)}" ${m.checked?'checked':''} aria-label="Mark ${esc(m.name)} purchased"><label>${esc(m.name)}</label><span class="item-qty">${esc(m.qty)}</span><button class="icon-btn" data-action="delete-manual" data-id="${esc(m.id)}" title="Remove item" style="width:27px;height:27px">${ic('trash')}</button></div>`).join('')}</section>`:''}
      ${!total?`<div class="empty-state"><div class="big">🛒</div><h3>Your list is ready when you are</h3><p>Add dinners to the meal planner to create a shopping list.</p>${btn('Plan some meals','go-planner','','btn btn-primary')}</div>`:''}
      ${stocked().length?`<div class="notice" style="margin-top:14px"><strong>Already in your pantry:</strong> ${stocked().map(i=>esc(i.name)).join(', ')}. We assume you have enough of each to cover the full recipe quantity.</div>`:''}
    </div><aside class="shopping-aside"><section class="retailer-card"><div class="eyebrow">READY TO SHOP?</div><h3>Choose your supermarket</h3><p>Open your chosen supermarket to do your shopping and arrange delivery there.</p><label class="field-label" for="retailer">Preferred retailer</label><select class="select-field" id="retailer"><option value="tesco" ${state.retailer==='tesco'?'selected':''}>Tesco</option><option value="sainsburys" ${state.retailer==='sainsburys'?'selected':''}>Sainsbury’s</option><option value="asda" ${state.retailer==='asda'?'selected':''}>Asda</option><option value="morrisons" ${state.retailer==='morrisons'?'selected':''}>Morrisons</option></select><button class="btn btn-primary" style="width:100%;margin-top:12px" data-action="open-retailer">Open supermarket ${ic('external')}</button><p class="hint" style="margin:11px 0 0"><strong>Demo limitation:</strong> Your basket does not transfer automatically. Copy your list and add products on the retailer's site. Orders and delivery are not processed by this app.</p></section>
    <section class="surface"><h3>Add something extra</h3><p style="font-size:12px">Milk, snacks or anything not part of a recipe.</p><form id="add-item-form"><label class="field-label" for="extra-name">Item</label><input class="text-field" id="extra-name" name="name" required maxlength="65" placeholder="e.g. Milk"><label class="field-label" for="extra-qty" style="margin-top:10px">Quantity (optional)</label><input class="text-field" id="extra-qty" name="qty" maxlength="30" placeholder="e.g. 2 litres"><button class="btn btn-primary" style="margin-top:12px;width:100%" type="submit">${ic('plus')} Add to list</button></form></section></aside></div>`;
  }
  function renderPantry(){const all=shopIngredients(),examples=RECIPES.flatMap(r=>r.ingredients.map(([id,name,qty,unit,aisle])=>({id,name,aisle})));const uniq=[...new Map(examples.map(i=>[i.id,i])).values()].sort((a,b)=>a.name.localeCompare(b.name));const display=uniq.filter(i=>['Cupboard','Chilled','Frozen','Fresh produce'].includes(i.aisle));const stockedCount=display.filter(i=>state.pantry.includes(i.id)).length;
    return `${pageHead('SAVE WHAT YOU ALREADY HAVE','My pantry','Tick the ingredients you already have at home.',btn(ic('cart')+' View shopping list','go-shopping','','btn'))}<div class="notice"><strong>How it works:</strong> Items marked as stocked won't appear on your shopping list. This demo treats pantry stock as a yes/no switch; it does not track how much is left.</div><div class="surface" style="margin-top:20px"><div class="section-heading"><h2>What's in your kitchen?</h2><span class="badge-soft">${stockedCount} stocked</span></div><p style="font-size:13px">Tap any ingredient to add or remove it from your pantry.</p><div class="pantry-items">${display.map(i=>{const checked=state.pantry.includes(i.id);return `<button class="pantry-item ${checked?'is-stocked':''}" data-action="pantry-toggle" data-id="${esc(i.id)}" aria-pressed="${checked}"><span>${esc(i.name)}</span>${checked?ic('check'):ic('plus')}</button>`}).join('')}</div></div><div class="help-callout" style="margin-top:16px"><strong>A small habit that helps:</strong> Before placing an order, check cupboards and the fridge to avoid buying things you already have.</div>`;
  }
  function renderHousehold(){return `${pageHead('BETTER TOGETHER','Your household','The people you plan and cook with.',btn(ic('settings')+' Settings','go-settings','','btn'))}<div class="setting-block"><div class="section-heading"><h2>${esc(state.name)}</h2><span class="badge-soft">Local demo</span></div><p>You can add names here to personalise this demo. Real invitations, accounts and automatic synchronisation across phones require a future backend.</p><div class="members">${state.members.map((name,i)=>`<div class="member"><div class="member-avatar">${esc(name.trim().slice(0,1).toUpperCase()||'?')}</div><span>${esc(name)}<small>${i===0?'This device':'Demo member'}</small></span>${i>0?`<button class="icon-btn" data-action="remove-member" data-index="${i}" aria-label="Remove ${esc(name)}" style="width:28px;height:28px">${ic('trash')}</button>`:''}</div>`).join('')}</div><form id="add-member-form" style="margin-top:18px;max-width:440px"><label class="field-label" for="member-name">Add a household member (demo)</label><div class="form-row"><input class="text-field" name="name" id="member-name" maxlength="40" required placeholder="First name"> <button class="btn btn-primary" type="submit">${ic('plus')} Add</button></div></form></div><div class="setting-block"><h3>Share your meal plan</h3><p>Copy a plain-text summary and send it in your family's usual messaging app. Edits will not sync automatically between devices.</p>${btn(ic('download')+' Copy weekly plan','copy-plan','','btn btn-primary')}</div>`}
  function renderSettings(){return `${pageHead('MAKE IT YOURS','Settings','Adjust the defaults that work for your home.')}<div class="setting-block"><h3>Weekly dinner budget</h3><p>Set an indicative budget for dinners on your plan. This does not track all groceries or actual receipts.</p><div class="settings-control"><label class="field-label" for="budget">Weekly target (£)</label><input class="text-field" id="budget" inputmode="decimal" type="number" min="1" max="2000" step="1" value="${esc(state.budget)}"></div></div><div class="setting-block"><h3>Default portions</h3><p>New meals will use this number of portions unless you choose something different.</p><div class="settings-control"><label class="field-label" for="servings">Portions per meal</label><select id="servings" class="select-field">${Array.from({length:12},(_,i)=>i+1).map(n=>`<option ${n===state.servings?'selected':''} value="${n}">${n} ${n===1?'portion':'portions'}</option>`).join('')}</select></div></div><div class="setting-block"><h3>Kitchen name</h3><div class="settings-control"><label class="field-label" for="kitchen-name">Household name</label><input class="text-field" id="kitchen-name" maxlength="48" value="${esc(state.name)}"></div></div><div class="setting-block"><h3>Export or restore demo data</h3><p>All your demo data lives in this browser. Download a backup as JSON, or restore an earlier backup. Do not store secrets or personal medical information here.</p><div style="display:flex;gap:10px;flex-wrap:wrap">${btn(ic('download')+' Download backup','export','','btn')}<label class="btn" for="import-file">Restore backup <input id="import-file" type="file" accept="application/json,.json" style="display:none"></label></div></div><div class="setting-block"><h3>Start fresh</h3><p>This clears demo meals, shopping ticks, pantry choices and names from this browser.</p>${btn(ic('trash')+' Reset demo data','reset','','btn btn-danger')}</div><div class="notice"><strong>Privacy:</strong> No app server receives your data in this demonstration. Links to external supermarkets open their own websites with separate privacy terms.</div>`}
  function render(){renderNav();document.getElementById('app').innerHTML=({home:renderHome,recipes:renderRecipes,planner:renderPlanner,shopping:renderShopping,pantry:renderPantry,household:renderHousehold,settings:renderSettings}[page]||renderHome)();document.title='Cook Together · '+(navItems.find(n=>n[0]===page)||navItems[0])[1];}
  function navigate(next){if(!navItems.some(n=>n[0]===next))next='home';page=next;if(location.hash!=='#'+next)location.hash=next;render();window.scrollTo({top:0,behavior:'instant'});document.getElementById('app').focus({preventScroll:true});}
  function toast(msg){const el=document.getElementById('toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),3200)}
  function showRecipe(id){const r=recipeById(id);if(!r)return;modalRecipe=id;const defaultDay=pendingDay||DAYS.find(d=>!state.plan[d])||'Monday';document.getElementById('modal-root').innerHTML=`<div class="modal-overlay" id="modal-backdrop"><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><div class="modal-top theme-${r.theme}"><span class="food">${r.emoji}</span><button class="modal-x" data-action="close-modal" aria-label="Close">×</button></div><div class="modal-body"><div class="eyebrow">${r.tags.slice(0,2).map(esc).join(' · ')}</div><h2 id="modal-title">${esc(r.title)}</h2><p>${esc(r.description)}</p><div class="summary-strip"><span class="badge-soft">⏱ ${r.time} minutes</span><span class="badge-soft">${r.servings} base portions</span><span class="badge-soft">~${pounds(r.cost)} base recipe</span></div><div class="modal-cols"><div><h3>Ingredients</h3><ul class="ingredients-list">${r.ingredients.map(i=>`<li>${esc(i[1])} — ${ingredientAmount(i[2],i[3])}</li>`).join('')}</ul></div><div><h3>How to make it</h3><ol class="steps-list">${r.steps.map(s=>`<li>${esc(s)}</li>`).join('')}</ol></div></div><div class="notice"><strong>Check ingredients:</strong> ${r.allergens.length?'Example allergen flags: '+r.allergens.map(esc).join(', ')+'. ':'No allergens flagged in this example, but this is not a guarantee. '}Always check actual labels, substitutions and individual dietary needs.</div><div class="modal-footer"><div class="modal-control"><div><label for="meal-day" class="field-label">Choose day</label><select class="select-field" id="meal-day">${DAYS.map(d=>`<option ${d===defaultDay?'selected':''}>${d}</option>`).join('')}</select></div><div><label for="meal-portions" class="field-label">Portions</label><select class="select-field" id="meal-portions">${Array.from({length:12},(_,i)=>i+1).map(n=>`<option value="${n}" ${n===state.servings?'selected':''}>${n}</option>`).join('')}</select></div></div><button class="btn btn-primary" data-action="add-meal" data-id="${r.id}">${ic('plus')} Add to my week</button></div></div></section></div>`;document.querySelector('.modal-x')?.focus();}
  // Accessible, mobile-first meal picker for a particular day. It reuses the existing recipe catalogue.
  const pickerChips=[['All','All'],['Quick','Quick'],['Budget','Budget'],['Vegetarian','Veggie'],['Favourites','♥ Saved']];
  function filteredPickerRecipes(){
    const q=pickerQuery.trim().toLocaleLowerCase('en-GB');
    return RECIPES.filter(r=>{
      const matches=pickerFilter==='All'||
        (pickerFilter==='Quick'&&r.time<=30)||
        (pickerFilter==='Budget'&&r.tags.includes('Budget'))||
        (pickerFilter==='Vegetarian'&&(r.tags.includes('Vegetarian')||r.tags.includes('Vegan')))||
        (pickerFilter==='Favourites'&&state.favorites.includes(r.id));
      const searchable=[r.title,r.description,...r.tags,...r.ingredients.map(x=>x[1])].join(' ').toLocaleLowerCase('en-GB');
      return matches&&(!q||searchable.includes(q));
    });
  }
  function pickerCard(r){
    const current=state.plan[pickerDay]?.id===r.id;
    const favourite=state.favorites.includes(r.id);
    return `<article class="picker-card ${current?'picker-card-current':''}">
      <div class="picker-card-row">
        <div class="picker-art theme-${r.theme}"><span role="img" aria-label="${esc(r.title)}">${r.emoji}</span></div>
        <div class="picker-card-content">
          <div class="picker-card-title-row"><h3>${esc(r.title)}</h3><button type="button" class="picker-heart ${favourite?'is-favourite':''}" data-action="picker-favourite" data-id="${esc(r.id)}" aria-pressed="${favourite}" aria-label="${favourite?'Remove':'Save'} ${esc(r.title)} ${favourite?'from':'to'} favourites">${ic('heart')}</button></div>
          <div class="picker-card-meta"><span>${ic('clock')} ${r.time} min</span><span>~${pounds(r.cost*pickerServings/r.servings)} / ${pickerServings} portions</span></div>
          <div class="picker-card-tags">${current?'<span class="picker-current-tag">On your plan</span>':r.tags.slice(0,2).map(t=>`<span>${esc(t)}</span>`).join('')}</div>
          <div class="picker-card-actions"><button type="button" class="picker-details-btn" data-action="picker-details" data-id="${esc(r.id)}" aria-expanded="false" aria-controls="picker-detail-${esc(r.id)}">Ingredients ${ic('arrow')}</button><button type="button" class="picker-choose-btn" data-action="picker-add" data-id="${esc(r.id)}" aria-label="${current?'Keep':'Choose'} ${esc(r.title)} for ${esc(pickerDay)} dinner">${ic(current?'check':'plus')} <span>${current?'Keep this':'Choose meal'}</span></button></div>
        </div>
      </div>
      <div class="picker-card-extra" id="picker-detail-${esc(r.id)}" hidden><p>${esc(r.description)}</p><div class="picker-ingredient-title">Ingredients for ${r.servings} portions</div><p>${r.ingredients.map(i=>esc(i[1])).join(' · ')}</p><p class="picker-allergen">${r.allergens.length?'Example allergens: '+r.allergens.map(esc).join(', ')+'.':'No allergens flagged in this demo.'} Always check actual packaging and substitutions.</p></div>
    </article>`;
  }
  function pickerResults(){
    const list=filteredPickerRecipes();
    return list.length?list.map(pickerCard).join(''):`<div class="picker-empty"><span aria-hidden="true">🥗</span><h3>No matching meals yet</h3><p>Try a different search or choose All meals.</p><button class="picker-reset" type="button" data-action="picker-reset">Show all meals</button></div>`;
  }
  function updatePickerResults(scrollTop=false){
    const resultEl=document.getElementById('picker-results');
    if(!resultEl)return;
    const list=filteredPickerRecipes();
    resultEl.innerHTML=pickerResults();
    const counter=document.getElementById('picker-count');
    if(counter)counter.textContent=`${list.length} ${list.length===1?'meal':'meals'} to choose from`;
    document.querySelectorAll('[data-action="picker-filter"]').forEach(el=>{const active=el.dataset.filter===pickerFilter;el.classList.toggle('is-active',active);el.setAttribute('aria-pressed',String(active))});
    const reset=document.getElementById('picker-clear-search');
    if(reset)reset.hidden=!pickerQuery;
    if(scrollTop)document.getElementById('picker-scroll')?.scrollTo({top:0});
  }
  function openMealPicker(day){
    if(!DAYS.includes(day))return;
    pickerDay=day;pickerQuery='';pickerFilter='All';
    pickerServings=state.plan[day]?.servings||state.servings;
    pickerPreviousFocus=document.activeElement;
    const root=document.getElementById('modal-root');
    root.innerHTML=`<div class="picker-backdrop" id="picker-backdrop"><section class="meal-picker" role="dialog" aria-modal="true" aria-labelledby="picker-title" aria-describedby="picker-description">
      <div class="picker-top">
        <div class="picker-handle" aria-hidden="true"></div>
        <div class="picker-heading-row"><div><div class="picker-kicker">YOUR WEEKLY MENU</div><h2 id="picker-title">What's for <span>${esc(day)}</span>?</h2></div><button class="picker-close" type="button" data-action="close-picker" aria-label="Close meal picker">×</button></div>
        <p id="picker-description" class="picker-subtitle">Pick a dinner. We'll add its ingredients to your shopping list.</p>
        <div class="picker-toolbar"><label class="picker-search">${ic('search')}<input type="search" id="picker-search" placeholder="Search meals…" autocomplete="off" aria-label="Search recipes, ingredients or dietary tags"><button id="picker-clear-search" type="button" data-action="picker-clear-search" aria-label="Clear search" hidden>×</button></label><label class="picker-portions"><span>Portions</span><select id="picker-portions" aria-label="Number of portions">${Array.from({length:12},(_,i)=>i+1).map(n=>`<option value="${n}" ${n===pickerServings?'selected':''}>${n}</option>`).join('')}</select></label></div>
        <div class="picker-chips" role="group" aria-label="Filter meals">${pickerChips.map(([key,label])=>`<button type="button" class="picker-chip ${key==='All'?'is-active':''}" aria-pressed="${key==='All'}" data-action="picker-filter" data-filter="${key}" aria-label="${key==='Quick'?'Quick meals (30 minutes or less)':key==='Vegetarian'?'Vegetarian and vegan meals':key==='Favourites'?'Your saved favourite meals':esc(label)}">${esc(label)}</button>`).join('')}</div>
        <div class="picker-results-heading"><strong id="picker-count" aria-live="polite"></strong><span>Tap Choose meal to add instantly</span></div>
      </div>
      <div class="picker-scroll" id="picker-scroll" tabindex="-1"><div class="picker-results" id="picker-results"></div></div>
      <div class="picker-foot"><span>${ic('check')} Your plan is saved on this device</span><button type="button" class="picker-foot-close" data-action="close-picker">Back to my week</button></div>
    </section></div>`;
    document.body.classList.add('picker-open');
    updatePickerResults();
    document.getElementById('picker-title')?.setAttribute('tabindex','-1');
    document.getElementById('picker-title')?.focus({preventScroll:true});
  }
  function closeMealPicker(restoreFocus=true){
    if(!pickerDay)return;
    pickerDay=null;pendingDay=null;document.getElementById('modal-root').innerHTML='';document.body.classList.remove('picker-open');
    if(restoreFocus&&pickerPreviousFocus?.isConnected)pickerPreviousFocus.focus({preventScroll:true});
    pickerPreviousFocus=null;
  }
  function closeModal(){modalRecipe=null;document.getElementById('modal-root').innerHTML='';}
  function toggleFav(id){const ix=state.favorites.indexOf(id);if(ix>=0)state.favorites.splice(ix,1);else state.favorites.push(id);save();render();toast(ix>=0?'Removed from favourites':'Saved to favourites')}
  function shoppingText(){const list=['Cook Together — Shopping list',''];const items=required();for(const aisle of [...new Set(items.map(x=>x.aisle))].sort()){list.push(aisle+':');items.filter(x=>x.aisle===aisle).forEach(i=>list.push((state.checked[i.key]?'[x] ':'[ ] ')+i.name+' — '+ingredientAmount(i.qty,i.unit)));list.push('')}if(state.manual.length){list.push('Extras:');state.manual.forEach(m=>list.push((m.checked?'[x] ':'[ ] ')+m.name+(m.qty?' — '+m.qty:'')));}list.push('','Review product amounts, dietary suitability and prices on the retailer website.');return list.join('\n')}
  function planText(){return ['Cook Together — Our weekly dinners','',...DAYS.map(d=>{const p=state.plan[d];const r=p&&recipeById(p.id);return d+': '+(r?r.title+' ('+p.servings+' portions)':'Not planned')}),'','Estimated dinner total: '+pounds(plannedCost()),'Indicative budget: '+pounds(state.budget),'Demo prices only.'].join('\n')}
  async function copy(text){try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(text);toast('Copied to clipboard');return;}const t=document.createElement('textarea');t.value=text;t.style.position='fixed';t.style.opacity='0';document.body.appendChild(t);t.select();const ok=document.execCommand('copy');t.remove();if(!ok)throw Error('Copy unsupported');toast('Copied to clipboard')}catch{toast('Copy unavailable. Try using HTTPS or print instead.')}}
  function backup(){const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='cook-together-backup.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),2000);toast('Backup downloaded')}
  function validateImport(data){if(!data||data.version!==1||!data.plan||typeof data.plan!=='object'||!Array.isArray(data.favorites)||!Array.isArray(data.pantry)||!Array.isArray(data.manual)||!Array.isArray(data.members))throw Error('Invalid backup');const out={...defaultState(),...data};out.budget=Math.min(2000,Math.max(1,Number(out.budget)||85));out.servings=Math.min(12,Math.max(1,Number(out.servings)||4));out.name=String(out.name||'Our kitchen').slice(0,48);out.members=out.members.slice(0,12).map(x=>String(x).slice(0,40));out.favorites=out.favorites.filter(x=>recipeById(x));out.pantry=out.pantry.filter(x=>typeof x==='string');out.manual=out.manual.slice(0,200).map(m=>({id:String(m.id||''),name:String(m.name||'').slice(0,65),qty:String(m.qty||'').slice(0,30),checked:!!m.checked}));out.plan=Object.fromEntries(DAYS.filter(d=>out.plan[d]&&recipeById(out.plan[d].id)).map(d=>[d,{id:out.plan[d].id,servings:Math.min(12,Math.max(1,Number(out.plan[d].servings)||4))}]));out.checked=(out.checked&&typeof out.checked==='object')?out.checked:{};out.retailer=['tesco','sainsburys','asda','morrisons'].includes(out.retailer)?out.retailer:'tesco';return out}
  const retailerLinks={tesco:'https://www.tesco.com/groceries/',sainsburys:'https://www.sainsburys.co.uk/gol-ui/groceries',asda:'https://groceries.asda.com/',morrisons:'https://groceries.morrisons.com/'};
  document.addEventListener('click',(ev)=>{
    const pb=ev.target.closest('[data-page]');if(pb){navigate(pb.dataset.page);return}
    if(ev.target.id==='modal-backdrop'){closeModal();return}
    if(ev.target.id==='picker-backdrop'){closeMealPicker();return}
    const el=ev.target.closest('[data-action]');if(!el)return;
    const act=el.dataset.action,id=el.dataset.id,day=el.dataset.day;
    if(act.startsWith('go-')){navigate(({ 'go-planner':'planner','go-recipes':'recipes','go-shopping':'shopping','go-settings':'settings' })[act]||'home');return}
    if(act==='favorite'){toggleFav(id);return}
    if(act==='recipe'){showRecipe(id);return}
    if(act==='close-modal'){closeModal();return}
    if(act==='close-picker'){closeMealPicker();return}
    if(act==='picker-filter'){pickerFilter=el.dataset.filter;updatePickerResults(true);return}
    if(act==='picker-clear-search'){pickerQuery='';const field=document.getElementById('picker-search');if(field){field.value='';field.focus()}updatePickerResults(true);return}
    if(act==='picker-reset'){pickerFilter='All';pickerQuery='';const field=document.getElementById('picker-search');if(field)field.value='';updatePickerResults(true);return}
    if(act==='picker-favourite'){const ix=state.favorites.indexOf(id);if(ix===-1)state.favorites.push(id);else state.favorites.splice(ix,1);save();updatePickerResults();return}
    if(act==='picker-details'){const extra=document.getElementById('picker-detail-'+id);if(!extra)return;extra.hidden=!extra.hidden;el.setAttribute('aria-expanded',String(!extra.hidden));el.innerHTML=(extra.hidden?'Ingredients':'Hide ingredients')+' '+ic('arrow');return}
    if(act==='picker-add'){if(!pickerDay||!recipeById(id))return;const chosenDay=pickerDay;state.plan[chosenDay]={id,servings:pickerServings};pendingDay=null;save();closeMealPicker(false);navigate('planner');toast('Added '+recipeById(id).title+' to '+chosenDay);return} 
    if(act==='filter'){filter=el.dataset.filter;render();return}
    if(act==='clear-filter'){filter='All';search='';render();return}
    if(act==='fill-day'||act==='change-day'){openMealPicker(day);return}
    if(act==='add-meal'){const chosen=document.getElementById('meal-day').value;const portions=Number(document.getElementById('meal-portions').value);state.plan[chosen]={id,servings:portions};pendingDay=null;save();closeModal();navigate('planner');toast('Added to '+chosen+' dinner');return}
    if(act==='remove-day'){delete state.plan[day];save();render();toast(day+' meal removed');return}
    if(act==='portion-minus'||act==='portion-plus'){const p=state.plan[day];if(p){p.servings=Math.max(1,Math.min(12,p.servings+(act==='portion-plus'?1:-1)));save();render()}return}
    if(act==='pantry-toggle'){const i=state.pantry.indexOf(id);if(i===-1)state.pantry.push(id);else state.pantry.splice(i,1);save();render();return}
    if(act==='delete-manual'){state.manual=state.manual.filter(x=>x.id!==id);save();render();return}
    if(act==='remove-member'){const i=Number(el.dataset.index);if(i>0&&i<state.members.length){state.members.splice(i,1);save();render()}return}
    if(act==='copy-shopping'){copy(shoppingText());return}
    if(act==='copy-plan'){copy(planText());return}
    if(act==='clear-checks'){state.checked={};state.manual.forEach(m=>m.checked=false);save();render();toast('Shopping ticks cleared');return}
    if(act==='print'){window.print();return}
    if(act==='export'){backup();return}
    if(act==='open-retailer'){window.open(retailerLinks[state.retailer]||retailerLinks.tesco,'_blank','noopener,noreferrer');return}
    if(act==='reset'){if(confirm('Reset Cook Together demo? All saved changes in this browser will be lost.')){state=defaultState();pendingDay=null;filter='All';search='';save();navigate('home');toast('Demo reset')}return}
  });
  document.addEventListener('input',e=>{if(e.target.id==='picker-search'){pickerQuery=e.target.value;updatePickerResults(true);return}if(e.target.id==='recipe-search'){search=e.target.value;const results=document.getElementById('recipe-results');if(results)results.innerHTML=recipeResults()}});
  document.addEventListener('change',async(e)=>{
    const el=e.target;
    if(el.id==='picker-portions'){pickerServings=Math.max(1,Math.min(12,Number(el.value)||4));updatePickerResults();return}
    if(el.dataset.action==='tick-ingredient'){state.checked[el.dataset.key]=el.checked;save();render();return}
    if(el.dataset.action==='tick-manual'){const m=state.manual.find(x=>x.id===el.dataset.id);if(m)m.checked=el.checked;save();render();return}
    if(el.id==='retailer'){state.retailer=el.value;save();return}
    if(el.id==='budget'){const val=Number(el.value);if(!Number.isFinite(val)||val<1||val>2000){toast('Enter a budget between £1 and £2,000');render();return}state.budget=Math.round(val);save();render();toast('Budget updated');return}
    if(el.id==='servings'){state.servings=Number(el.value);save();toast('Default portions updated');return}
    if(el.id==='kitchen-name'){const name=el.value.trim();if(name){state.name=name.slice(0,48);save();render();toast('Kitchen name updated')}else{render()}return}
    if(el.id==='import-file'&&el.files[0]){try{if(el.files[0].size>1024*1024)throw Error('Backup is too large');const raw=JSON.parse(await el.files[0].text());if(!confirm('Restore backup? This replaces the demo data currently saved in this browser.'))return;state=validateImport(raw);save();navigate('home');toast('Backup restored')}catch(err){toast('Could not restore: please select a valid Cook Together backup.')}return}
  });
  document.addEventListener('submit',(e)=>{
    if(e.target.id==='add-item-form'){e.preventDefault();const form=new FormData(e.target),name=String(form.get('name')||'').trim(),qty=String(form.get('qty')||'').trim();if(!name)return;state.manual.push({id:'m-'+Date.now()+'-'+Math.random().toString(36).slice(2,8),name:name.slice(0,65),qty:qty.slice(0,30),checked:false});save();render();toast('Extra item added')}
    if(e.target.id==='add-member-form'){e.preventDefault();const name=String(new FormData(e.target).get('name')||'').trim();if(!name)return;if(state.members.length>=12){toast('Maximum 12 demo members');return}state.members.push(name.slice(0,40));save();render();toast('Demo member added')}
  });
  window.addEventListener('keydown',e=>{
    if(e.key==='Escape'){if(pickerDay){closeMealPicker();e.preventDefault()}else if(modalRecipe){closeModal();e.preventDefault()}return}
    if(e.key==='Tab'&&pickerDay){
      const dialog=document.querySelector('.meal-picker');if(!dialog)return;
      const focusables=[...dialog.querySelectorAll('button:not([disabled]):not([hidden]),input:not([disabled]),select:not([disabled])')].filter(el=>el.getClientRects().length);
      if(!focusables.length)return;
      const first=focusables[0],last=focusables.at(-1);
      if(e.shiftKey&&(document.activeElement===first||!dialog.contains(document.activeElement))){e.preventDefault();last.focus()}
      else if(!e.shiftKey&&(document.activeElement===last||!dialog.contains(document.activeElement))){e.preventDefault();first.focus()}
    }
  });
  window.addEventListener('hashchange',()=>{const id=location.hash.replace('#','');if(id!==page&&navItems.some(n=>n[0]===id)){page=id;render()}});
  const initial=location.hash.slice(1);page=navItems.some(n=>n[0]===initial)?initial:'home';render();
  if('serviceWorker'in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('./service-worker.js').catch(()=>{});
})();
