# How to try the updated meal picker with GitHub Pages

1. First back up your existing GitHub repository or create a new test repository/branch. This is a reconstructed demo, not necessarily the exact code currently live on your GitHub Pages address.
2. Unzip `Cook_Together_Meal_Picker_v0.2.0.zip`.
3. Upload the **contents** of the unzipped folder to your repository root (do not upload the ZIP by itself). `index.html` must live at the root, next to `app.js`, `styles.css`, and `recipes.js`.
4. Commit all changes together. In **Settings → Pages**, select branch `main`, folder `/ (root)` if you're using branch deployment.
5. When the deployment completes, refresh your app. For a previously cached version, close and reopen the browser tab; if still stale, clear this site's cached data and reload.
6. Open **Meal planner**, tap **Choose a meal** or **Change**, and try adding an item with a different portion count.

**Caution:** do not replace a different live application's code with this entire package just to change one picker. Instead, supply the live project's repository or ZIP so that only its meal-picker components can be modified.
